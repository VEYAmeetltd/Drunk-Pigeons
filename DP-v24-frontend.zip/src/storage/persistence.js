import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  bestDist: 'dp_bestDistance',
  injured: 'dp_pigeonsInjured',
  sound: 'dp_soundEnabled',
  pigeon: 'dp_selectedPigeon',
  map: 'dp_selectedMap',
  unlocked: 'dp_unlockedPigeons',
  leet: 'dp_leetUnlock',
  purchased: 'dp_purchasedPigeons',
  bundle: 'dp_bundleOwned',
  easy: 'dp_easyOwned',
  removeAds: 'dp_removeAdsOwned',
  bestDistSilly: 'dp_bestDistanceSilly',
  playerId: 'dp_playerId',
  nickname: 'dp_nickname',
  submittedBest: 'dp_submittedBest',
  submittedBestSilly: 'dp_submittedBestSilly',
  drunk: 'dp_drunkLevel',
  rulesAccepted: 'dp_rulesAccepted',
  hiddenNames: 'dp_hiddenNames',
};

async function getNumber(key, def) {
  try {
    const v = await AsyncStorage.getItem(key);
    return v == null ? def : Number(v);
  } catch {
    return def;
  }
}

async function getString(key, def) {
  try {
    const v = await AsyncStorage.getItem(key);
    return v == null ? def : v;
  } catch {
    return def;
  }
}

export const Persistence = {
  async loadAll() {
    const [bestDist, bestDistSilly, injured, sound, pigeon, map, unlocked, leet, purchased, bundle, easy, removeAds, drunk] = await Promise.all([
      getNumber(KEYS.bestDist, 0),
      getNumber(KEYS.bestDistSilly, 0),
      getNumber(KEYS.injured, 0),
      getString(KEYS.sound, '1'),
      getString(KEYS.pigeon, 'classic'),
      getString(KEYS.map, 'day'),
      getString(KEYS.unlocked, ''),
      getString(KEYS.leet, '0'),
      getString(KEYS.purchased, ''),
      getString(KEYS.bundle, '0'),
      getString(KEYS.easy, '0'),
      getString(KEYS.removeAds, '0'),
      getString(KEYS.drunk, '0.5'),
    ]);
    return {
      bestDistance: bestDist,
      bestDistanceSilly: bestDistSilly,
      pigeonsInjured: injured,
      soundEnabled: sound !== '0',
      selectedPigeon: pigeon,
      selectedMap: map,
      unlockedPigeons: unlocked ? unlocked.split(',').filter(Boolean) : [],
      leetUnlock: leet === '1',
      purchasedPigeons: purchased ? purchased.split(',').filter(Boolean) : [],
      bundleOwned: bundle === '1',
      easyModeOwned: easy === '1',
      removeAdsOwned: removeAds === '1',
      drunkLevel: (() => { const n = parseFloat(drunk); return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.5; })(),
    };
  },
  setDrunk(level) {
    AsyncStorage.setItem(KEYS.drunk, String(level)).catch(() => {});
  },
  setEasyMode(on) {
    AsyncStorage.setItem(KEYS.easy, on ? '1' : '0').catch(() => {});
  },
  setRemoveAds(on) {
    AsyncStorage.setItem(KEYS.removeAds, on ? '1' : '0').catch(() => {});
  },
  setBestDistanceSilly(v) {
    AsyncStorage.setItem(KEYS.bestDistSilly, String(v)).catch(() => {});
  },
  setSubmittedBestSilly(v) {
    AsyncStorage.setItem(KEYS.submittedBestSilly, String(v)).catch(() => {});
  },
  setPurchased(list) {
    AsyncStorage.setItem(KEYS.purchased, list.join(',')).catch(() => {});
  },
  setBundle(on) {
    AsyncStorage.setItem(KEYS.bundle, on ? '1' : '0').catch(() => {});
  },
  setPlayerId(v) {
    AsyncStorage.setItem(KEYS.playerId, v).catch(() => {});
  },
  setNickname(v) {
    AsyncStorage.setItem(KEYS.nickname, v).catch(() => {});
  },
  setRulesAccepted(version) {
    AsyncStorage.setItem(KEYS.rulesAccepted, version || '').catch(() => {});
  },
  getRulesAccepted() {
    return getString(KEYS.rulesAccepted, '');
  },
  async getHiddenNames() {
    const raw = await getString(KEYS.hiddenNames, '');
    return raw ? raw.split(',').filter(Boolean) : [];
  },
  async addHiddenName(normalized) {
    const list = await this.getHiddenNames();
    if (!list.includes(normalized)) {
      list.push(normalized);
      AsyncStorage.setItem(KEYS.hiddenNames, list.join(',')).catch(() => {});
    }
    return list;
  },
  setSubmittedBest(v) {
    AsyncStorage.setItem(KEYS.submittedBest, String(v)).catch(() => {});
  },
  async loadLeaderboard() {
    const [playerId, nickname, submittedBest, submittedBestSilly] = await Promise.all([
      getString(KEYS.playerId, ''),
      getString(KEYS.nickname, ''),
      getNumber(KEYS.submittedBest, 0),
      getNumber(KEYS.submittedBestSilly, 0),
    ]);
    return { playerId, nickname, submittedBest, submittedBestSilly };
  },
  setLeet(on) {
    AsyncStorage.setItem(KEYS.leet, on ? '1' : '0').catch(() => {});
  },
  setBestDistance(v) {
    AsyncStorage.setItem(KEYS.bestDist, String(v)).catch(() => {});
  },
  setInjured(v) {
    AsyncStorage.setItem(KEYS.injured, String(v)).catch(() => {});
  },
  setSound(on) {
    AsyncStorage.setItem(KEYS.sound, on ? '1' : '0').catch(() => {});
  },
  setPigeon(id) {
    AsyncStorage.setItem(KEYS.pigeon, id).catch(() => {});
  },
  setMap(id) {
    AsyncStorage.setItem(KEYS.map, id).catch(() => {});
  },
  setUnlocked(list) {
    AsyncStorage.setItem(KEYS.unlocked, list.join(',')).catch(() => {});
  },
};
