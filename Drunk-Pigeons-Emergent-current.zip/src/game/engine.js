import { CONFIG, fatLevelFor, pigeonRadiusFor } from '../config';
import { createPintEffect } from './pintEffect';
import { FAMILIES, buildGeometry, hitTestSegment, projectionMargin } from './obstacleGeometry';
import { pickEncounter, isNonBuildingEncounter } from './obstacleAppearance';

const PPM = CONFIG.PIXELS_PER_METRE;
const OW = CONFIG.OBSTACLE_WIDTH;

// Pure(ish) game simulation. No rendering. Mutates internal state each step.
// Rendering layer reads getSnapshot(). Collision/scoring use plain JS state.
export function createEngine({ onScore, onChip, onCrash, onSkinnyJab, onPint, onPintEffectChange }) {
  let W = 400;
  let H = 800;

  const pigeon = { x: 0, y: 0, vy: 0 };
  const obstacles = [];
  let spawnIndex = 0;
  const chips = [];
  const feathers = [];

  let scrollSpeed = CONFIG.SPEED_BASE;
  let score = 0;
  let chipCount = 0;
  // fatness driver — separate from total chipCount so a Skinny Jab can reset the
  // pigeon's current size without erasing lifetime chip stats/score.
  let fatChips = 0;
  let skinnyJabCount = 0;
  let popT = 0; // timestamp of the last Skinny Jab collection (drives the POP! effect)
  let jabChance = CONFIG.SKINNY_JAB_CHANCE; // dev-overridable
  const jab = { active: false, x: 0, y: 0, anim: 0 };
  const pint = { active: false, x: 0, y: 0, anim: 0 };
  let pintChance = CONFIG.PINT_CHANCE; // dev-overridable
  const beer = createPintEffect(onPintEffectChange);
  let distance = 0;
  let running = false;
  let dead = false;
  // guarantees a genuinely non-rectangular silhouette shows up early each run
  let nonBuildingSeenEarly = false;
  let invincibleUntil = 0;
  let usedRevive = false;
  let flapPulse = 0;
  // 1000m blackout Easter egg
  let eventTriggered = false; // fired once this run
  let blackoutStartT = 0;
  let blackoutEndT = 0;
  let quietUntilT = 0; // suppress obstacle/chip spawns until this time (blackout + recovery)
  const dirtyObstacles = new Set();
  let T = CONFIG; // active tuning (standard = CONFIG; Easy Mode overrides via reset)

  // Dev-only perf instrumentation (see requirements: instrument chunk-creation
  // time + frame duration). performance.now() calls are cheap (~microseconds)
  // and placeObstacle runs at most once every ~1-2s, so this is left always-on
  // rather than __DEV__-gated; it costs nothing measurable in production and
  // the numbers are only ever surfaced through the existing dev HUD.
  const perfNow = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  let lastPlaceObstacleMs = 0;
  let lastStepMs = 0;
  let recycleCount = 0; // dev instrumentation: total pool-slot recycles this run

  // Window heckler (tiny angry person) — single slot, bound to an obstacle window.
  const heckler = { active: false, obsIndex: -1, side: 'bottom', wx: 0, wy: 0, life: 0, insultR: 0, reactionR: 0, id: 0 };
  let hecklerTimer = 4;
  let hecklerPending = false;

  for (let i = 0; i < CONFIG.OBSTACLE_POOL; i++) {
    obstacles.push({ active: false, x: 0, topH: 0, gap: CONFIG.GAP_BASE, kind: 0, seed: 0, passed: false });
  }
  for (let i = 0; i < CONFIG.CHIP_POOL; i++) {
    chips.push({ active: false, x: 0, y: 0, eaten: false, anim: 0 });
  }
  for (let i = 0; i < CONFIG.FEATHER_POOL; i++) {
    feathers.push({ active: false, x: 0, y: 0, vx: 0, vy: 0, rot: 0, vr: 0, life: 0 });
  }


  function groundY() {
    return H - CONFIG.GROUND_H;
  }

  function difficulty() {
    const speed = Math.min(T.SPEED_MAX, T.SPEED_BASE + score * T.SPEED_PER_SCORE);
    const gap = Math.max(T.GAP_MIN, T.GAP_BASE - score * T.GAP_SHRINK_PER_SCORE);
    const spacing = Math.max(T.SPACING_MIN, T.SPACING_BASE - score * T.SPACING_SHRINK_PER_SCORE);
    return { speed, gap, spacing };
  }

  function placeObstacle(idx, x) {
    // if a heckler is bound to this slot, release it before reuse
    if (heckler.active && heckler.obsIndex === idx) heckler.active = false;
    const { gap } = difficulty();
    const minTop = T.MIN_TOP;
    const maxTop = groundY() - T.MIN_BOTTOM - gap;
    let topH = minTop + Math.random() * Math.max(20, maxTop - minTop);
    // Easy Mode: clamp vertical change vs the previous building so there are never
    // aggressive high/low transitions (gentle, forgiving flight path).
    if (T.MAX_TOP_DELTA > 0) {
      let prevTopH = null;
      let maxX = -Infinity;
      for (const o of obstacles) {
        if (o.active && o.x > maxX) { maxX = o.x; prevTopH = o.topH; }
      }
      if (prevTopH != null) {
        topH = Math.max(prevTopH - T.MAX_TOP_DELTA, Math.min(prevTopH + T.MAX_TOP_DELTA, topH));
        topH = Math.max(minTop, Math.min(Math.max(minTop, maxTop), topH));
      }
    }
    const o = obstacles[idx];
    o.active = true;
    o.x = x;
    o.topH = topH;
    o.gap = gap;
    o.kind = Math.floor(Math.random() * 4);
    o.seed = Math.floor(Math.random() * 1000000);

    // Decide the genuine geometry family for each side (either can be null =
    // open sky). Guarantee at least one non-rectangular silhouette by the
    // 4th spawn of the run, matching the verification requirement.
    const curIdx = spawnIndex;
    const mustVary = curIdx === 3 && !nonBuildingSeenEarly;
    const enc = pickEncounter({ mustVary, hard: T.HARD_GEOMETRY });
    if (curIdx < 4 && isNonBuildingEncounter(enc)) nonBuildingSeenEarly = true;
    o.topFamily = enc.topFamily;
    o.bottomFamily = enc.bottomFamily;
    const bottomH = groundY() - (topH + gap);
    const geomOpts = { scale: T.GEOM_SCALE, intrudeBottom: T.GEOM_INTRUDE_BOTTOM, intrudeTop: T.GEOM_INTRUDE_TOP };
    o.topGeo = o.topFamily && o.topFamily !== FAMILIES.BUILDING ? buildGeometry(o.topFamily, { H: topH, OW, seed: o.seed, ...geomOpts }) : null;
    o.bottomGeo = o.bottomFamily && o.bottomFamily !== FAMILIES.BUILDING ? buildGeometry(o.bottomFamily, { H: bottomH, OW, seed: o.seed, ...geomOpts }) : null;
    o.topMargin = o.topGeo ? projectionMargin(o.topGeo.segments, OW) : 0;
    o.bottomMargin = o.bottomGeo ? projectionMargin(o.bottomGeo.segments, OW) : 0;

    o.spawnIndex = spawnIndex++;
    o.passed = false;
    dirtyObstacles.add(idx);
    generateChipsForObstacle(idx);
  }

  function lastObstacleX() {
    let max = -Infinity;
    for (const o of obstacles) if (o.active && o.x > max) max = o.x;
    return max;
  }

  // Attach a tiny angry heckler to a valid window on a fully on-screen BUILDING
  // side only — a lamp post / crane / tree / etc has no window to shout from, so
  // those sides are never eligible (root cause of people appearing on/inside
  // non-building scenery). The person becomes a dependent of that obstacle slot
  // (moves/dies with it).
  const WIN_W = 36;
  const WIN_H = 36;
  const ROOF_CLEARANCE = 24;    // keep clear of the roof/chimney/antenna cluster at the gap-facing edge
  let ceilingClearance = 96; // visual safe area, independent of physics/difficulty
  const FRONT_CLEARANCE = 46;   // keep clear of the shop/pub/door signage at street level
  function trySpawnHeckler() {
    if (heckler.active) return false;
    const gY = groundY();
    // Every candidate is a concrete, valid window slot: {idx, side, lo, hi} where
    // lo/hi bound the window's top-y within that specific BUILDING side's own bounds.
    const cands = [];
    for (let i = 0; i < obstacles.length; i++) {
      const o = obstacles[i];
      // building must be fully on-screen (window can fit completely on screen)
      if (!o.active || o.x < W * 0.45 || o.x + OW > W - 4) continue;
      if (o.topFamily === FAMILIES.BUILDING) {
        const lo = ceilingClearance;
        const hi = o.topH - ROOF_CLEARANCE - WIN_H;
        if (hi > lo) cands.push({ idx: i, side: 'top', lo, hi });
      }
      if (o.bottomFamily === FAMILIES.BUILDING) {
        const bottomTop = o.topH + o.gap;
        const lo = bottomTop + ROOF_CLEARANCE;
        const hi = gY - FRONT_CLEARANCE - WIN_H;
        if (hi > lo) cands.push({ idx: i, side: 'bottom', lo, hi });
      }
    }
    if (cands.length === 0) return false; // retry shortly when an eligible building arrives
    const pick = cands[Math.floor(Math.random() * cands.length)];
    const top = pick.lo + Math.random() * (pick.hi - pick.lo);
    heckler.active = true;
    heckler.obsIndex = pick.idx;
    heckler.side = pick.side;
    heckler.wx = OW / 2; // window centre within the column
    heckler.wy = top + WIN_H / 2; // absolute vertical centre (building doesn't move vertically)
    heckler.life = 1.5 + Math.random() * 0.5;
    heckler.insultR = Math.random();
    heckler.reactionR = Math.random();
    heckler.id += 1;
    hecklerPending = true;
    return true;
  }

  function spawnChip(x, y) {
    const c = chips.find((c) => !c.active);
    if (!c) return;
    c.active = true;
    c.eaten = false;
    c.anim = 0;
    c.x = x;
    c.y = y;
  }

  // Validate a chip's FULL bounds (+safe padding) against ground, ceiling and every
  // active building. Returns true only if the chip sits entirely in open flying space.
  function isChipPosSafe(x, y) {
    const r = CONFIG.CHIP_SIZE * 0.5;
    const pad = 12;
    const gY = groundY();
    if (y - r - pad < 6) return false;
    if (y + r + pad > gY) return false;
    for (const o of obstacles) {
      if (!o.active) continue;
      const bx1 = o.x - pad;
      const bx2 = o.x + OW + pad;
      if (x + r < bx1 || x - r > bx2) continue; // not horizontally near this column
      // near this column: chip must fit fully inside the open gap band
      if (y - r - pad < o.topH) return false; // would clip the top building
      if (y + r + pad > o.topH + o.gap) return false; // would clip the bottom building
    }
    return true;
  }

  function placeIfSafe(x, y) {
    if (isChipPosSafe(x, y)) spawnChip(x, y);
  }

  // Validate the FULL Skinny Jab sprite bounds (+padding) — same principle as chips.
  function isJabPosSafe(x, y) {
    const r = CONFIG.SKINNY_JAB_SIZE * 0.5;
    const pad = 14;
    if (y - r - pad < 6) return false;
    if (y + r + pad > groundY()) return false;
    for (const o of obstacles) {
      if (!o.active) continue;
      if (x + r < o.x - pad || x - r > o.x + OW + pad) continue;
      if (y - r - pad < o.topH) return false;
      if (y + r + pad > o.topH + o.gap) return false;
    }
    return true;
  }

  // Rare roll on each obstacle spawn: only when sufficiently fat, only one at a
  // time, and only into a fully validated safe position (else skip the spawn).
  function maybeSpawnSkinnyJab(B) {
    if (jab.active) return;
    if (fatChips < CONFIG.SKINNY_JAB_MIN_FAT) return;
    if (Math.random() >= jabChance) return;
    const cx = B.x + OW / 2;
    const cy = B.topH + B.gap / 2;
    for (const oy of [0, -20, 20, -40, 40]) {
      if (isJabPosSafe(cx, cy + oy)) {
        jab.active = true;
        jab.x = cx;
        jab.y = cy + oy;
        jab.anim = 0;
        return;
      }
    }
  }

  // Pub pint: fairly common, one at a time, validated safe placement (reuses the
  // same bounds check as the jab since sizes match). Avoidable drunkenness hazard.
  function maybeSpawnPint(B) {
    if (pint.active) return;
    if (Math.random() >= pintChance) return;
    const cx = B.x + OW / 2;
    const cy = B.topH + B.gap / 2;
    for (const oy of [0, -22, 22, -44, 44]) {
      if (isJabPosSafe(cx, cy + oy)) {
        pint.active = true;
        pint.x = cx;
        pint.y = cy + oy;
        pint.anim = 0;
        return;
      }
    }
  }

  // Generate validated chips for a newly placed obstacle: a couple inside its gap
  // corridor, plus a short trail in the OPEN sky between it and the previous obstacle.
  function generateChipsForObstacle(idx) {
    const B = obstacles[idx];
    if (!B || !B.active) return;
    const r = CONFIG.CHIP_SIZE * 0.5;
    const pad = 12;

    // 1) up to 2 chips inside B's own gap (safe by construction, still validated)
    const gapCy = B.topH + B.gap / 2;
    const spread = T.CHIP_GAP_SPREAD;
    let placedGap = 0;
    for (const oy of [0, -spread, spread]) {
      if (placedGap >= 2) break;
      if (isChipPosSafe(B.x + OW / 2, gapCy + oy)) {
        spawnChip(B.x + OW / 2, gapCy + oy);
        placedGap += 1;
      }
    }

    // 2) trail in the open span between the previous building and B
    let prev = null;
    for (const o of obstacles) {
      if (o.active && o !== B && o.x < B.x) {
        if (!prev || o.x > prev.x) prev = o;
      }
    }
    if (prev) {
      const x1 = prev.x + OW + pad + r + 8;
      const x2 = B.x - pad - r - 8;
      if (x2 - x1 > 44) {
        const n = 2 + Math.floor(Math.random() * 3); // 2-4
        const form = Math.floor(Math.random() * 4); // line / arc / rise / fall
        const gY = groundY();
        const baseY = 100 + Math.random() * (gY - 200);
        for (let k = 0; k < n; k++) {
          const t = n === 1 ? 0.5 : k / (n - 1);
          const x = x1 + (x2 - x1) * t;
          let y = baseY;
          if (form === 1) y = baseY - Math.sin(t * Math.PI) * 70;
          else if (form === 2) y = baseY - (t - 0.5) * 120;
          else if (form === 3) y = baseY + (t - 0.5) * 120;
          placeIfSafe(x, y); // each chip validated independently; invalid ones skipped
        }
      }
    }
    maybeSpawnSkinnyJab(B);
    if (!jab.active) maybeSpawnPint(B);
  }

  function explodeFeathers(x, y, feather) {
    let spawned = 0;
    for (const f of feathers) {
      if (f.active) continue;
      const ang = Math.random() * Math.PI * 2;
      const spd = 120 + Math.random() * 320;
      f.active = true;
      f.x = x;
      f.y = y;
      f.vx = Math.cos(ang) * spd;
      f.vy = Math.sin(ang) * spd - 120;
      f.rot = Math.random() * 360;
      f.vr = (Math.random() - 0.5) * 720;
      f.life = 1;
      spawned++;
      if (spawned >= 14) break;
    }
  }

  function reset(width, height, tuning, hecklerSafeTop = 96) {
    T = tuning ? { ...CONFIG, ...tuning } : CONFIG;
    W = width;
    H = height;
    ceilingClearance = Number.isFinite(hecklerSafeTop) ? Math.max(22, hecklerSafeTop) : 96;
    pigeon.x = W * CONFIG.PIGEON_X_RATIO;
    pigeon.y = H * 0.4;
    pigeon.vy = 0;
    scrollSpeed = CONFIG.SPEED_BASE;
    score = 0;
    chipCount = 0;
    fatChips = 0;
    skinnyJabCount = 0;
    popT = 0;
    jab.active = false;
    pint.active = false;
    beer.reset();
    distance = 0;
    running = false;
    spawnIndex = 0;
    dead = false;
    invincibleUntil = 0;
    usedRevive = false;
    nonBuildingSeenEarly = false;
    eventTriggered = false;
    blackoutStartT = 0;
    blackoutEndT = 0;
    quietUntilT = 0;
    heckler.active = false;
    heckler.id = 0;
    hecklerPending = false;
    hecklerTimer = 3.5 + Math.random() * 3;
    obstacles.forEach((o) => (o.active = false));
    chips.forEach((c) => (c.active = false));
    feathers.forEach((f) => (f.active = false));
    // Seed first obstacles off to the right.
    const { spacing } = difficulty();
    let x = W + 120;
    for (let i = 0; i < 3; i++) {
      placeObstacle(i, x);
      x += spacing;
    }
  }

  function flap() {
    if (!running || dead) return;
    pigeon.vy = CONFIG.FLAP_VELOCITY * beer.flapScale;
    flapPulse = 1;
  }

  // Begin the run from the READY (paused) state. Idempotent: only the first call
  // transitions READY -> RUNNING. Physics/obstacles/scoring start on the next step.
  function start() {
    if (running || dead) return false;
    running = true;
    return true;
  }

  function collides(now) {
    if (now < invincibleUntil) return false;
    const r = pigeonRadiusFor(fatLevelFor(fatChips));
    const py = pigeon.y;
    // ground
    if (py + r >= groundY()) return true;
    // obstacles: BUILDING sides stay a solid full-width rect (unchanged);
    // every other family hit-tests its own real segments (pole/arm/mast/jib/
    // plank/trunk/canopy/beam/cable/...) — never one rectangular wrapper.
    const px = pigeon.x;
    const w = CONFIG.OBSTACLE_WIDTH;
    for (const o of obstacles) {
      if (!o.active) continue;
      const margin = Math.max(o.topMargin || 0, o.bottomMargin || 0);
      if (px + r < o.x - margin || px - r > o.x + w + margin) continue;
      // top side
      if (o.topFamily === FAMILIES.BUILDING) {
        const nx = Math.max(o.x, Math.min(px, o.x + w));
        const ny = Math.max(0, Math.min(py, o.topH));
        if ((px - nx) ** 2 + (py - ny) ** 2 < r * r) return true;
      } else if (o.topGeo) {
        for (const seg of o.topGeo.segments) {
          if (hitTestSegment(px, py, r, seg, o.x, 0)) return true;
        }
      }
      // bottom side
      const bTop = o.topH + o.gap;
      if (o.bottomFamily === FAMILIES.BUILDING) {
        const nx = Math.max(o.x, Math.min(px, o.x + w));
        const ny = Math.max(bTop, Math.min(py, groundY()));
        if (py + r > bTop && (px - nx) ** 2 + (py - ny) ** 2 < r * r) return true;
      } else if (o.bottomGeo) {
        for (const seg of o.bottomGeo.segments) {
          if (hitTestSegment(px, py, r, seg, o.x, bTop)) return true;
        }
      }
    }
    return false;
  }

  function step(dt, now) {
    const t0 = perfNow();
    stepImpl(dt, now);
    lastStepMs = perfNow() - t0;
  }

  function stepImpl(dt, now) {
    // feathers always simulate (for crash animation continuity)
    for (const f of feathers) {
      if (!f.active) continue;
      f.vy += 900 * dt;
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      f.rot += f.vr * dt;
      f.life -= dt * 0.7;
      if (f.life <= 0) f.active = false;
    }

    if (flapPulse > 0) flapPulse = Math.max(0, flapPulse - dt * 5);

    if (!running || dead) return;

    beer.step(dt);
    const { speed, spacing } = difficulty();
    scrollSpeed = speed;

    // physics
    pigeon.vy = Math.min(CONFIG.MAX_FALL_SPEED, pigeon.vy + CONFIG.GRAVITY * dt);
    pigeon.y += pigeon.vy * dt;
    if (pigeon.y < 12) {
      pigeon.y = 12;
      if (pigeon.vy < 0) pigeon.vy = 0;
    }
    distance += speed * dt;

    // 1000m "pigeon closes its eyes" blackout — fires once per run.
    // Clears the world to open sky so the blind stretch is fair, suppresses
    // spawns during the blackout + a short recovery buffer, then resumes.
    if (!eventTriggered && Math.floor(distance / PPM) >= CONFIG.BLACKOUT_TRIGGER_M) {
      eventTriggered = true;
      blackoutStartT = now;
      blackoutEndT = now + CONFIG.BLACKOUT_MS;
      quietUntilT = blackoutEndT + CONFIG.BLACKOUT_RECOVERY_MS;
      obstacles.forEach((o) => (o.active = false));
      chips.forEach((c) => (c.active = false));
      heckler.active = false;
    }

    // move obstacles + scoring + recycle
    const w = CONFIG.OBSTACLE_WIDTH;
    for (let i = 0; i < obstacles.length; i++) {
      const o = obstacles[i];
      if (!o.active) continue;
      o.x -= speed * dt;
      if (!o.passed && o.x + w < pigeon.x) {
        o.passed = true;
        score += 1;
        if (onScore) onScore(score);
      }
      if (o.x + w < -20) {
        o.active = false;
        if (heckler.active && heckler.obsIndex === i) heckler.active = false;
      }
    }
    // Spawn the NEXT chunk well BEFORE it can be seen — SPAWN_LOOKAHEAD pushes
    // the generation boundary far past the visible right edge, so the one-time
    // buildGeometry()/chip-safety-validation work in placeObstacle() always
    // completes many frames before the chunk scrolls into view (previously it
    // was generated only ~40px off-screen, i.e. a fraction of a second before
    // becoming visible, causing the reported spawn-time hitch). Spacing
    // between obstacles (T.SPACING_BASE/MIN, the difficulty) is untouched —
    // only WHERE the next one is first created shifts outward.
    // gated by quietUntilT so the 1000m blackout keeps an open, obstacle-free sky
    const lx = lastObstacleX();
    const lookaheadX = W + T.SPAWN_LOOKAHEAD;
    if (now >= quietUntilT && lx < lookaheadX - spacing) {
      const free = obstacles.findIndex((o) => !o.active);
      if (free >= 0) {
        const t0 = perfNow();
        placeObstacle(free, Math.max(lookaheadX, lx + spacing));
        lastPlaceObstacleMs = perfNow() - t0;
        recycleCount++;
      }
    }

    // move chips + collection
    const rr = pigeonRadiusFor(fatLevelFor(fatChips));
    for (const c of chips) {
      if (!c.active) continue;
      if (c.eaten) {
        c.anim += dt * 4;
        if (c.anim >= 1) c.active = false;
        continue;
      }
      c.x -= speed * dt;
      if (c.x < -40) {
        c.active = false;
        continue;
      }
      const dx = c.x - pigeon.x;
      const dy = c.y - pigeon.y;
      const pick = rr + CONFIG.CHIP_SIZE * 0.5;
      if (dx * dx + dy * dy < pick * pick) {
        c.eaten = true;
        c.anim = 0;
        chipCount += 1;
        fatChips += 1;
        if (onChip) onChip(chipCount, fatChips);
      }
    }

    // Skinny Jab power-up: instant fatness reset and clear the beer penalty.
    if (jab.active) {
      jab.anim += dt;
      jab.x -= speed * dt;
      if (jab.x < -40) {
        jab.active = false;
      } else {
        const jdx = jab.x - pigeon.x;
        const jdy = jab.y - pigeon.y;
        const jpick = rr + CONFIG.SKINNY_JAB_SIZE * 0.5;
        if (jdx * jdx + jdy * jdy < jpick * jpick) {
          jab.active = false;
          fatChips = 0; // instant deflation to original size (total chips untouched)
          beer.sober(); // restore vision and full flap strength immediately
          skinnyJabCount += 1;
          popT = now;
          explodeFeathers(pigeon.x, pigeon.y - 8);
          if (onSkinnyJab) onSkinnyJab();
        }
      }
    }

    // Pub pint: vision/flight penalty and a full barrel roll on every collection.
    if (pint.active) {
      pint.anim += dt;
      pint.x -= speed * dt;
      if (pint.x < -40) {
        pint.active = false;
      } else {
        const bdx = pint.x - pigeon.x;
        const bdy = pint.y - pigeon.y;
        const bpick = rr + CONFIG.PINT_SIZE * 0.5;
        if (bdx * bdx + bdy * bdy < bpick * bpick) {
          pint.active = false;
          beer.collect();
          if (onPint) onPint();
        }
      }
    }

    // collision
    if (collides(now)) {
      beer.reset();
      dead = true;
      running = false;
      explodeFeathers(pigeon.x, pigeon.y);
      if (onCrash) onCrash({ score, chips: chipCount, distance: Math.floor(distance / PPM), skinnyJabCount });
    }

    // window heckler: bound to its building; expire on life, or when the building
    // is gone / has scrolled off. Never repositioned independently.
    if (heckler.active) {
      const o = obstacles[heckler.obsIndex];
      heckler.life -= dt;
      const px = o && o.active ? o.x + heckler.wx : -9999;
      if (!o || !o.active || px < -60 || px > W + 60 || heckler.life <= 0) {
        heckler.active = false;
      }
    }
    hecklerTimer -= dt;
    if (hecklerTimer <= 0) {
      // A pole or an off-screen building is not a successful comedy event.
      // Retry that missed opportunity instead of skipping another 3.5–8 seconds.
      hecklerTimer = trySpawnHeckler() ? 3.5 + Math.random() * 4.5 : 0.25;
    }
  }

  // Revive: reposition to safe spot, grant temporary invincibility, keep score/chips.
  function revive(now) {
    if (usedRevive) return false;
    beer.reset();
    usedRevive = true;
    dead = false;
    running = true;
    // clear obstacles near the pigeon so it doesn't instantly die
    const w = CONFIG.OBSTACLE_WIDTH;
    for (const o of obstacles) {
      if (o.active && o.x + w > pigeon.x - 40 && o.x < pigeon.x + W * 0.55) {
        o.active = false;
      }
    }
    pigeon.y = H * 0.4;
    pigeon.vy = 0;
    invincibleUntil = now + CONFIG.REVIVE_INVINCIBLE_MS;
    return true;
  }

  // 0..1 alpha for the 1000m blackout overlay — pure function of time (fade in/hold/out).
  function currentBlackout(now) {
    if (!eventTriggered || now >= blackoutEndT || now < blackoutStartT) return 0;
    const fadeIn = 450;
    const fadeOut = 800;
    if (now < blackoutStartT + fadeIn) return (now - blackoutStartT) / fadeIn;
    if (now > blackoutEndT - fadeOut) return Math.max(0, (blackoutEndT - now) / fadeOut);
    return 1;
  }

  function getSnapshot(now) {
    const fat = fatLevelFor(fatChips);
    const inv = now < invincibleUntil ? 1 : 0;
    const tilt = Math.max(-28, Math.min(70, pigeon.vy * 0.06));
    return {
      px: pigeon.x,
      py: pigeon.y,
      t: now,
      tilt,
      flap: flapPulse,
      fat,
      inv,
      blackout: currentBlackout(now),
      distM: Math.floor(distance / PPM),
      distPx: distance,
      dead: dead ? 1 : 0,
      heckler: (() => {
        const o = heckler.active ? obstacles[heckler.obsIndex] : null;
        const on = o && o.active;
        return {
          id: heckler.id,
          x: on ? o.x + heckler.wx : -999,
          y: heckler.wy,
          w: WIN_W,
          h: WIN_H,
          active: on ? 1 : 0,
          life: Math.max(0, heckler.life),
        };
      })(),
      obs: obstacles.map((o) => ({ x: o.x, active: o.active ? 1 : 0 })),
      chips: chips.map((c) => ({
        x: c.x,
        y: c.y,
        active: c.active ? 1 : 0,
        anim: c.anim,
        eaten: c.eaten ? 1 : 0,
      })),
      feathers: feathers.map((f) => ({
        x: f.x,
        y: f.y,
        rot: f.rot,
        active: f.active ? 1 : 0,
        life: Math.max(0, f.life),
      })),
      jab: { x: jab.x, y: jab.y, active: jab.active ? 1 : 0, anim: jab.anim },
      pint: { x: pint.x, y: pint.y, active: pint.active ? 1 : 0, anim: pint.anim },
      boost: beer.active ? 1 : 0,
      beerRoll: beer.rollDegrees,
      beerRemainingMs: beer.remainingMs,
      pop: popT,
    };
  }

  function getObstacleGeom() {    return obstacles.map((o) => ({
      active: o.active,
      topH: o.topH,
      gap: o.gap,
      kind: o.kind,
      seed: o.seed,
      spawnIndex: o.spawnIndex,
      topFamily: o.topFamily,
      bottomFamily: o.bottomFamily,
      topGeo: o.topGeo,
      bottomGeo: o.bottomGeo,
    }));
  }

  function consumeHeckler() {
    if (!hecklerPending) return null;
    hecklerPending = false;
    return {
      id: heckler.id,
      insultR: heckler.insultR,
      reactionR: heckler.reactionR,
      lifeMs: Math.round(heckler.life * 1000),
    };
  }

  function consumeDirty() {
    if (dirtyObstacles.size === 0) return null;
    const arr = Array.from(dirtyObstacles);
    dirtyObstacles.clear();
    return arr;
  }

  return {
    reset,
    step,
    flap,
    start,
    revive,
    getSnapshot,
    getObstacleGeom,
    consumeDirty,
    consumeHeckler,
    getPerfStats() {
      return { stepMs: lastStepMs, placeObstacleMs: lastPlaceObstacleMs, recycleCount };
    },
    get score() {
      return score;
    },
    get chipCount() {
      return chipCount;
    },
    get skinnyJabCount() {
      return skinnyJabCount;
    },
    setSkinnyJabChance(c) {
      if (Number.isFinite(c) && c >= 0 && c <= 1) jabChance = c;
    },
    devSetFat(n) {
      // dev/test only: force currentFatness (drives visible size + hitbox). Harmless in prod.
      if (Number.isFinite(n) && n >= 0) fatChips = Math.floor(n);
    },
    setPintChance(c) {
      if (Number.isFinite(c) && c >= 0 && c <= 1) pintChance = c;
    },
    get distanceMeters() {
      return Math.floor(distance / PPM);
    },
    get dead() {
      return dead;
    },
    get running() {
      return running;
    },
    get usedRevive() {
      return usedRevive;
    },
    canRevive() {
      return dead && !usedRevive;
    },
  };
}
