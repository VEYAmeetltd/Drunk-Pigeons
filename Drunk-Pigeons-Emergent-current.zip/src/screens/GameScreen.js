import React, { forwardRef, memo, useEffect, useImperativeHandle, useRef, useState, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable, useWindowDimensions, Platform, AppState } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing, cancelAnimation } from 'react-native-reanimated';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Background from '../components/Background';
import BeerWorld from '../components/BeerWorld';
import { PigeonView, PigeonSpeechBubble, ObstacleView, ChipView, JabView, PintView, FeatherView, HecklerView, DrunkScreenFX, SkinnyToast, DEV_MOUNT_STATS } from '../components/GameEntities';
import GameOverOverlay from './GameOverOverlay';
import Button from '../ui/Button';
import { createEngine } from '../game/engine';
import { advanceScriptedSpeech, SCRIPTED_SPEECH_MS } from '../game/pigeonSpeech';
import { createFixedStepScheduler, SIM_STEP } from '../game/frameScheduler';
import { CONFIG, EASY_TUNING, fatLevelFor, FAT_LABELS, EXTRA_FAT_LABELS, extraFatLevelFor, formatInt } from '../config';
import { getMapForSelection, modeForSelection } from '../data/maps';
import { randomDeathMessage } from '../data/deathMessages';
import { pickInsult, pickReaction } from '../data/insults';
import { generateRunId } from '../leaderboard/api';
import { Audio } from '../audio/audio';
import { Ads } from '../ads/ads';
import { DEV_AD_STATS, flushImpressions } from '../ads/sponsorCampaigns';
import { DIAGNOSTICS_ENABLED, logFrameGap, printDiagnosticsReport } from '../diagnostics';
import { FONT, COLORS } from '../ui/theme';

// GameScreen owns a few low-frequency UI states (restart, game over, pigeon
// size tiers, etc.). Memoized entity wrappers ensure those state changes do
// not re-run every pooled renderer when its props are unchanged.
const StableBackground = memo(Background);
const StableObstacleView = memo(ObstacleView);
const StableChipView = memo(ChipView);
const StableJabView = memo(JabView);
const StablePintView = memo(PintView);
const StableFeatherView = memo(FeatherView);
const StableHecklerView = memo(HecklerView);
const StablePigeonView = memo(PigeonView);
const StablePigeonSpeechBubble = memo(PigeonSpeechBubble);
const StableDrunkScreenFX = memo(DrunkScreenFX);

function emptySnapshot() {
  return {
    px: -999, py: 0, t: 0, tilt: 0, flap: 0, fat: 0, inv: 0, dead: 0, distM: 0, distPx: 0, blackout: 0,
    jab: { x: -999, y: 0, active: 0, anim: 0 },
    pop: 0, boost: 0, beerRoll: 0, beerRemainingMs: 0,
    heckler: { id: 0, x: -999, y: 0, w: 36, h: 36, active: 0, life: 0 },
    obs: Array.from({ length: CONFIG.OBSTACLE_POOL }, () => ({ x: -999, active: 0 })),
    chips: Array.from({ length: CONFIG.CHIP_POOL }, () => ({ x: -999, y: 0, active: 0, anim: 0, eaten: 0 })),
    feathers: Array.from({ length: CONFIG.FEATHER_POOL }, () => ({ x: -999, y: 0, rot: 0, active: 0, life: 0 })),
  };
}

// Full-screen fade-to-black for the 1000m "pigeon closes its eyes" Easter egg.
// Polls the JS-owned snapshot (no UI-thread readback) and never
// blocks touch input, so the pigeon keeps flapping through the blind stretch.
function BlackoutOverlay({ telemetry }) {
  const [a, setA] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      try {
        setA(telemetry.current.blackout || 0);
      } catch (e) {
        if (typeof __DEV__ !== 'undefined' && __DEV__) console.warn('[GameScreen] blackout HUD read failed', e);
      }
    }, 50);
    return () => clearInterval(id);
  }, [telemetry]);
  if (a <= 0.001) return null;
  return (
    <View
      style={[styles.blackout, { opacity: a }]}
      pointerEvents="none"
      testID="blackout-overlay"
    >
      <Text style={[styles.blackoutTxt, { opacity: Math.max(0, (a - 0.35) / 0.65) }]}>
        This is what it looks like when a pigeon closes it's eyes.
      </Text>
    </View>
  );
}

// Live distance readout — isolates re-renders to just this tiny component.
function DistanceHUD({ telemetry }) {
  const [m, setM] = useState(0);
  useEffect(() => {
    const id = setInterval(() => {
      try {
        setM(telemetry.current.distM || 0);
      } catch (e) {
        if (typeof __DEV__ !== 'undefined' && __DEV__) console.warn('[GameScreen] distance HUD read failed', e);
      }
    }, 60);
    return () => clearInterval(id);
  }, [telemetry]);
  return (
    <View style={styles.distHud} testID="distance-hud" pointerEvents="none">
      <Text style={styles.distTxt}>{formatInt(m)}m</Text>
    </View>
  );
}

// The chip count changes far more often than any other React-rendered game
// state. Keep that update inside this tiny leaf instead of invalidating the
// whole GameScreen (background, obstacle pool, 36 chips and 16 feathers).
const ChipHUD = memo(forwardRef(function ChipHUD(_, ref) {
  const [count, setCount] = useState(0);
  useImperativeHandle(ref, () => ({ setCount }), []);
  return (
    <View style={styles.chipHud} testID="chip-hud">
      <View style={styles.chipIcon} />
      <Text style={styles.chipTxt}>{count}</Text>
    </View>
  );
}));

// Comic "POP!" for Skinny Jab. Kept fixed and driven by the low-frequency pickup
// signal: moving native Text with every world snapshot caused an Android frame spike.
function PopText({ signal = 0 }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!signal) return undefined;
    setVisible(true);
    const id = setTimeout(() => setVisible(false), 900);
    return () => clearTimeout(id);
  }, [signal]);
  return (
    <View style={[styles.pop, visible ? styles.calloutShown : styles.calloutHidden]} pointerEvents="none" testID="skinny-jab-pop">
      <Text style={styles.popTxt}>POP!</Text>
    </View>
  );
}

// READY-state "TAP TO FLAP" prompt with a subtle pulse. Never intercepts touches
// (pointerEvents none) — the full-screen flap layer beneath handles the tap.
function ReadyHint({ visible, preparing = false }) {
  const p = useSharedValue(1);
  useEffect(() => {
    if (!visible) {
      cancelAnimation(p);
      p.value = 1;
      return undefined;
    }
    p.value = withRepeat(withTiming(1.08, { duration: 620, easing: Easing.inOut(Easing.quad) }), -1, true);
    return () => cancelAnimation(p);
  }, [p, visible]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: p.value }], opacity: 0.9 + (p.value - 1) }));
  return (
    <View style={[styles.hint, visible ? styles.calloutShown : styles.calloutHidden]} pointerEvents="none" testID="tap-to-flap-hint">
      <Animated.Text style={[styles.hintTxt, style]}>{preparing ? 'PREPARING THE MANOR' : 'TAP TO FLAP'}</Animated.Text>
      <Text style={styles.hintSub}>{preparing ? 'getting your pigeon ready' : 'keep the drunk pigeon airborne'}</Text>
    </View>
  );
}

export default function GameScreen({ pigeon, mapSelection, bestDistance = 0, drunkStrength = 1, drunkLevel = 0.5, removeAdsOwned = false, onCrash, onExit }) {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const world = useSharedValue(emptySnapshot());
  // JS-only mirror. HUD and ad timers must never synchronously fetch world
  // from the UI thread: the engine already produced these values on JS.
  const telemetry = useRef({ distM: 0, distPx: 0, blackout: 0 });
  const mode = modeForSelection(mapSelection); // 'normal' | 'easy' (stable for this instance)
  const [activeMap, setActiveMap] = useState(() => getMapForSelection(mapSelection));

  const [fatChipsCur, setFatChipsCur] = useState(0); // currentFatness (resets on Skinny Jab); drives visible size
  const [extraLevel, setExtraLevel] = useState(0);
  const [deflateN, setDeflateN] = useState(0); // increments on jab -> squash animation
  const [skinnySignal, setSkinnySignal] = useState(0); // retriggers the permanently-mounted Skinny Jab toast
  const [obsGeom, setObsGeom] = useState(() =>
    Array.from({ length: CONFIG.OBSTACLE_POOL }, () => ({ active: false, topH: 0, gap: CONFIG.GAP_BASE, kind: 0 }))
  );
  const [over, setOver] = useState(null); // {message, score, chips, isNewBest}
  const [canRevive, setCanRevive] = useState(true);
  const [reviveBusy, setReviveBusy] = useState(false);
  const [reviveMsg, setReviveMsg] = useState('');
  const [shield, setShield] = useState(false);
  const [started, setStarted] = useState(false);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [heckler, setHeckler] = useState({ id: 0, text: '', reaction: 'fist' });
  const [pintBoost, setPintBoost] = useState(false); // mirrors simulation-owned beer penalty transitions
  const rendererReadyRef = useRef(false);
  const [rendererReady, setRendererReady] = useState(false);
  const onRendererPrepared = useCallback(() => {
    rendererReadyRef.current = true;
    setRendererReady(true);
  }, []);
  const chipHudRef = useRef(null);
  const fatLevelRef = useRef(0);
  const extraLevelRef = useRef(0);
  // Roadman's one-time lines follow his pigeon in a small static SVG bubble.
  // They take priority over ordinary quips and use active simulation time.
  const [scriptedLine, setScriptedLine] = useState({ text: 'Wargwarn?', visible: false });
  const roadmanFlagsRef = useRef({ wargwarn: false, wargwarn50: false, wargwarn100: false });
  const scriptedRemainingRef = useRef(0);
  const hideScriptedLine = useCallback(() => {
    setScriptedLine((line) => ({ ...line, visible: false }));
  }, []);
  const showScriptedLine = useCallback((text) => {
    scriptedRemainingRef.current = SCRIPTED_SPEECH_MS;
    setScriptedLine({ text, visible: true });
  }, []);

  const engineRef = useRef(null);
  const rafRef = useRef(0);
  const schedulerRef = useRef(null); // fixed-timestep scheduler (60Hz sim cap, decoupled from display Hz)
  const cbRef = useRef({});
  const shieldTimer = useRef(null);
  const pausedRef = useRef(false);
  const runIdRef = useRef('');
  const runStartRef = useRef(0);
  // Authoritative READY->RUNNING flag read synchronously by the tap handler
  // (refs avoid stale closures / waiting on React render before the first flap).
  const startedRef = useRef(false);
  // DEV-only input instrumentation (never rendered in production).
  const inputStatsRef = useRef({ raw: 0, accepted: 0, flaps: 0, ignored: 0, lastReason: '' });
  const [devStats, setDevStats] = useState(null);
  // DEV-only chunk-spawn / frame-time instrumentation (never rendered in
  // production). Polled at a low cadence (not every frame) into a small HUD
  // so a profile build can visually confirm chunk generation stays cheap and
  // off the frame that becomes visible.
  const perfStatsRef = useRef({ stepMs: 0, chunkMs: 0, maxChunkMs: 0 });
  const [perfHud, setPerfHud] = useState(null);
  const mountBaselineRef = useRef(null);
  // DEV-only: raw rAF timestamp of the previous callback + a bounded ring
  // buffer of frame gaps > 25ms (distance/timestamp at each gap), so a
  // physical-device profile build can pinpoint exactly when a real stall
  // happened (e.g. correlating it against a SponsorBillboard rotation).
  const lastRafNowRef = useRef(null);
  const frameGapLogRef = useRef([]);

  // keep latest callbacks
  cbRef.current.onChip = (c, fatCur) => {
    // Updating parent-owned state for every chip used to re-render the entire
    // gameplay tree. The counter now updates only its small leaf component;
    // parent state changes only when a visible fatness/callout tier changes.
    if (chipHudRef.current) chipHudRef.current.setCount(c);
    const nextFatLevel = fatLevelFor(fatCur);
    if (nextFatLevel !== fatLevelRef.current) {
      fatLevelRef.current = nextFatLevel;
      setFatChipsCur(fatCur);
    }
    const nextExtraLevel = extraFatLevelFor(c);
    if (nextExtraLevel !== extraLevelRef.current) {
      extraLevelRef.current = nextExtraLevel;
      setExtraLevel(nextExtraLevel);
    }
    Audio.chip();
  };
  cbRef.current.onSkinnyJab = () => {
    Audio.pop();
    fatLevelRef.current = 0;
    setFatChipsCur(0); // instant fatness reset; squash + toast add the comedic beat
    setDeflateN((n) => n + 1);
    setSkinnySignal((n) => n + 1);
  };
  cbRef.current.onPint = () => {
    Audio.pint();
  };
  cbRef.current.onPintEffectChange = (active) => setPintBoost(active);
  cbRef.current.onCrash = ({ score: sc, chips: ch, distance: dist }) => {
    // Freeze the screen-owned simulation clock immediately. The engine already
    // marks itself dead, but without this gate the rAF publisher and independent
    // character-event scheduler could keep working behind the Game Over card.
    pausedRef.current = true;
    Audio.crash();
    setPintBoost(false);
    // Best Score = longest distance travelled, in meters. This is the ONLY source of
    // truth for "best" — never obstacle-pass counts, chips, or fatness tiers.
    const isNewBest = dist > bestDistance;
    if (isNewBest) setTimeout(() => Audio.highscore(), 250);
    scriptedRemainingRef.current = 0;
    hideScriptedLine();
    setOver({ message: randomDeathMessage(), chips: ch, distance: dist, isNewBest });
    flushImpressions(); // game over is a natural pause point — persist queued sponsor impressions
    printDiagnosticsReport(`game over @ ${dist}m`); // preview-build-visible (adb logcat), see diagnostics.js
    Ads.registerDeath();
    if (onCrash)
      onCrash({
        score: sc,
        chips: ch,
        distance: dist,
        mode,
        runId: runIdRef.current,
        runDuration: (performance.now() - runStartRef.current) / 1000,
        reviveUsed: !!(engineRef.current && engineRef.current.usedRevive),
      });
  };

  const buildEngine = useCallback(() => {
    return createEngine({
      onChip: (c, fat) => cbRef.current.onChip(c, fat),
      onCrash: (info) => cbRef.current.onCrash(info),
      onSkinnyJab: () => cbRef.current.onSkinnyJab(),
      onPint: () => cbRef.current.onPint(),
      onPintEffectChange: (active) => cbRef.current.onPintEffectChange(active),
    });
  }, []);

  const startRun = useCallback(() => {
    const eng = engineRef.current;
    // Every brand-new run explicitly re-opens the same clock gate that Game Over
    // closes. Resetting the scheduler prevents the overlay/ad wait from becoming
    // a simulation catch-up burst on the first frame of the next run.
    pausedRef.current = false;
    if (schedulerRef.current) schedulerRef.current.reset(performance.now());
    setPintBoost(false);
    // RANDOM MANOR re-picks one of the 3 standard maps for every brand-new run.
    const m = getMapForSelection(mapSelection);
    setActiveMap(m);
    eng.reset(width, height, mode === 'easy' ? EASY_TUNING : undefined, insets.top + 74);
    runIdRef.current = generateRunId();
    // Anti-cheat run timing starts on the FIRST gameplay tap (READY->RUNNING),
    // not when PLAY was pressed. Seeded here only to avoid a stale value.
    runStartRef.current = 0;
    startedRef.current = false;
    setStarted(false);
    if (chipHudRef.current) chipHudRef.current.setCount(0);
    fatLevelRef.current = 0;
    extraLevelRef.current = 0;
    setFatChipsCur(0);
    setExtraLevel(0);
    setOver(null);
    setCanRevive(true);
    setReviveBusy(false);
    setReviveMsg('');
    setShield(false);
    setObsGeom(eng.getObstacleGeom());
    // reset() marks its initially seeded slots dirty; their geometry was just
    // copied above, so consume that marker instead of repeating the same
    // React update on the first running frame.
    eng.consumeDirty();
    const initialSnapshot = eng.getSnapshot(performance.now());
    telemetry.current = initialSnapshot;
    world.value = initialSnapshot;
    // A brand-new run resets the Roadman scripted-line triggers (revive must NOT).
    roadmanFlagsRef.current = { wargwarn: false, wargwarn50: false, wargwarn100: false };
    scriptedRemainingRef.current = 0;
    setScriptedLine((line) => ({ ...line, visible: false }));
    setHeckler((current) => ({ ...current, id: 0 }));
  }, [width, height, mapSelection, mode, insets.top]);

  // init engine + loop
  useEffect(() => {
    engineRef.current = buildEngine();
    startRun();
    schedulerRef.current = createFixedStepScheduler();
    schedulerRef.current.reset(performance.now());

    const loop = (now) => {
      const eng = engineRef.current;
      if (DIAGNOSTICS_ENABLED) {
        // Bounded frame-gap log: records the RAW wall-clock gap between
        // consecutive rAF callbacks (before any 60Hz scheduler capping), so a
        // physical-device preview build can see exactly when/where a real frame
        // stall happened (native Android jank shows up here even though the sim
        // itself is correctly capped at 60Hz). Ring buffer, bounded to 40
        // entries — never grows unbounded, never causes a re-render.
        const last = lastRafNowRef.current;
        lastRafNowRef.current = now;
        if (last != null) {
          const rawGapMs = now - last;
          if (rawGapMs > 25) {
            const distM = Math.floor(telemetry.current.distM || 0);
            const log = frameGapLogRef.current;
            log.push({ gapMs: Math.round(rawGapMs), distM, t: Math.round(now) });
            if (log.length > 40) log.shift();
            logFrameGap(rawGapMs, distM, now);
          }
        }
      }
      if (pausedRef.current) {
        schedulerRef.current.reset(now); // don't let a pause build up a step backlog for resume
        rafRef.current = requestAnimationFrame(loop);
        return;
      }

      // Fixed 60Hz simulation/publish cadence: on a 90Hz/120Hz display, rAF
      // fires more often than this loop actually steps the engine or
      // publishes a new world.value — this is what was producing thousands
      // of fresh getSnapshot() allocations/transfers per second and the
      // reported whole-world stalls. requestAnimationFrame itself is still
      // scheduled at native refresh rate (kept for lowest-latency touch
      // pickup on the NEXT frame), only the sim/publish work is capped.
      const steps = schedulerRef.current.consume(now);
      let stepped = false;
      for (let i = 0; i < steps; i++) {
        if (startedRef.current && !eng.dead) {
          advanceScriptedSpeech(scriptedRemainingRef, SIM_STEP, hideScriptedLine);
        }
        eng.step(SIM_STEP, now);
        stepped = true;
      }

      if (stepped) {
        const snap = eng.getSnapshot(now);
        telemetry.current = snap;
        world.value = snap;
        if (typeof __DEV__ !== 'undefined' && __DEV__) {
          const p = eng.getPerfStats();
          const stats = perfStatsRef.current;
          stats.stepMs = p.stepMs;
          stats.chunkMs = p.placeObstacleMs;
          stats.maxChunkMs = Math.max(stats.maxChunkMs, p.placeObstacleMs);
        }
        if (pigeon.id === 'roadman') {
          const flags = roadmanFlagsRef.current;
          if (!flags.wargwarn50 && snap.distM >= 50) {
            flags.wargwarn50 = true;
            showScriptedLine('I said wargwarn fam?');
          } else if (!flags.wargwarn100 && snap.distM >= 100) {
            flags.wargwarn100 = true;
            showScriptedLine("A'ight say less, deekhed");
          }
        }
        const dirty = eng.consumeDirty();
        if (dirty) {
          // Preserve object identity for every unchanged pool slot so the
          // memoized obstacle renderer skips it. Previously one recycled slot
          // replaced all nine geometry objects and re-rendered the full pool.
          const latest = eng.getObstacleGeom();
          setObsGeom((previous) => {
            const next = previous.slice();
            for (const index of dirty) next[index] = latest[index];
            return next;
          });
        }
        const hk = eng.consumeHeckler();
        if (hk) {
          setHeckler({ id: hk.id, text: pickInsult(hk.insultR), reaction: pickReaction(hk.reactionR) });
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafRef.current);
      if (shieldTimer.current) clearTimeout(shieldTimer.current);
      scriptedRemainingRef.current = 0;
      flushImpressions(); // leaving GameScreen — persist any queued sponsor impressions now
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sponsor impressions are queued in memory only (see sponsorCampaigns.js);
  // the one AsyncStorage write they eventually need must never land on a live
  // gameplay frame. Backgrounding/inactivating the app is a natural, already-paused
  // moment to persist them (also covers the OS killing the app shortly after).
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'background' || state === 'inactive') flushImpressions();
    });
    return () => sub.remove();
  }, []);

  // DEV-only: low-cadence poll of the perf ref into state so the on-screen
  // HUD updates without adding a React re-render to the hot per-frame path.
  useEffect(() => {
    if (typeof __DEV__ === 'undefined' || !__DEV__) return undefined;
    const id = setInterval(() => {
      const base = mountBaselineRef.current;
      const mountsSinceStart = base
        ? {
            building: DEV_MOUNT_STATS.building - base.building,
            structureShape: DEV_MOUNT_STATS.structureShape - base.structureShape,
            obstacleView: DEV_MOUNT_STATS.obstacleView - base.obstacleView,
          }
        : null;
      setPerfHud({
        ...perfStatsRef.current,
        mountsSinceStart,
        recycles: engineRef.current ? engineRef.current.getPerfStats().recycleCount : 0,
        frameGaps: frameGapLogRef.current.slice(-3),
        adRotations: DEV_AD_STATS.rotations,
        adStorageWrites: DEV_AD_STATS.storageWrites,
      });
    }, 250);
    return () => clearInterval(id);
  }, []);

  // keyboard support (web)
  useEffect(() => {
    if (Platform.OS !== 'web' || typeof window === 'undefined') return;
    const onKey = (e) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        doFlap();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Single authoritative gameplay tap handler. Fires on touch-DOWN (onPressIn).
  // Reads refs so it always sees the live game state; the first tap in READY both
  // starts the run (and its official timing) AND applies exactly one flap.
  const doFlap = useCallback(() => {
    const st = inputStatsRef.current;
    st.raw += 1;
    if (!rendererReadyRef.current) {
      st.ignored += 1;
      st.lastReason = 'preparing';
      return;
    }
    Audio.unlock();
    const eng = engineRef.current;
    if (!eng || eng.dead) {
      st.ignored += 1;
      st.lastReason = 'dead/no-engine';
      if (typeof __DEV__ !== 'undefined' && __DEV__) setDevStats({ ...st, state: 'GAME_OVER' });
      return;
    }
    if (pausedRef.current) {
      st.ignored += 1;
      st.lastReason = 'paused';
      if (typeof __DEV__ !== 'undefined' && __DEV__) setDevStats({ ...st, state: 'PAUSED' });
      return;
    }
    if (!startedRef.current) {
      // READY -> RUNNING on the first valid tap. Snapshot the obstacle-pool
      // mount counters right here so the dev HUD can show any mounts that
      // happen AFTER this point (should stay exactly 0 for the pooled fix
      // to be verified correct).
      startedRef.current = true;
      runStartRef.current = performance.now();
      eng.start();
      setStarted(true);
      if (typeof __DEV__ !== 'undefined' && __DEV__) {
        mountBaselineRef.current = { ...DEV_MOUNT_STATS };
      }
      if (pigeon.id === 'roadman' && !roadmanFlagsRef.current.wargwarn) {
        roadmanFlagsRef.current.wargwarn = true;
        showScriptedLine('Wargwarn?');
      }
    }
    st.accepted += 1;
    eng.flap();
    st.flaps += 1;
    Audio.flap();
    if (typeof __DEV__ !== 'undefined' && __DEV__) setDevStats({ ...st, state: 'RUNNING' });
  }, []);

  const doRevive = useCallback(() => {
    const eng = engineRef.current;
    if (!eng.canRevive()) return;
    if (reviveBusy) return; // button protection — no duplicate ad requests
    setReviveBusy(true);
    setReviveMsg('');
    Ads.showRewardedRevive(
      () => {
        // verified reward callback — grant the revive, continue the SAME run
        const now = performance.now();
        eng.revive(now);
        schedulerRef.current.reset(now);
        pausedRef.current = false;
        Audio.revive();
        setOver(null);
        setCanRevive(false);
        setReviveBusy(false);
        setShield(true);
        if (shieldTimer.current) clearTimeout(shieldTimer.current);
        shieldTimer.current = setTimeout(() => setShield(false), CONFIG.REVIVE_INVINCIBLE_MS);
      },
      () => {
        // no ad / incomplete reward — return cleanly to Game Over
        setReviveBusy(false);
        setReviveMsg('NO AD AVAILABLE — THE PIGEONS HAVE PROBABLY DRUNK THE SERVER.');
      }
    );
  }, [reviveBusy]);

  const openRestartConfirm = useCallback(() => {
    const eng = engineRef.current;
    if (!eng || eng.dead) return; // only during an active run
    Audio.ui();
    pausedRef.current = true;
    setConfirmRestart(true);
    flushImpressions(); // gameplay is now paused — a safe moment to persist queued impressions
  }, []);

  const cancelRestart = useCallback(() => {
    Audio.ui();
    setConfirmRestart(false);
    schedulerRef.current.reset(performance.now());
    pausedRef.current = false;
  }, []);

  const confirmRestartNow = useCallback(() => {
    Audio.ui();
    setConfirmRestart(false);
    pausedRef.current = false;
    schedulerRef.current.reset(performance.now());
    startRun();
  }, [startRun]);

  const handleExit = useCallback(() => {
    flushImpressions(); // leaving the game screen for the menu — persist queued impressions
    onExit();
  }, [onExit]);

  const fatLevel = fatLevelFor(fatChipsCur);

  return (
    <View style={styles.root}>
      <BeerWorld boosted={pintBoost} drunkLevel={drunkLevel} onPrepared={onRendererPrepared}>
      <StableBackground theme={activeMap} width={width} height={height} world={world} telemetry={telemetry} removeAds={removeAdsOwned} />

      {/* obstacles */}
      {obsGeom.map((g, i) => (
        <StableObstacleView key={i} world={world} index={i} geom={g} theme={activeMap} screenH={height} />
      ))}

      {/* window heckler (environmental comedy) */}
      <StableHecklerView world={world} eventId={heckler.id} text={heckler.text} reaction={heckler.reaction} theme={activeMap} screenW={width} topInset={insets.top} />

      {/* chips */}
      {Array.from({ length: CONFIG.CHIP_POOL }).map((_, i) => (
        <StableChipView key={i} world={world} index={i} />
      ))}

      {/* Skinny Jab rare pickup */}
      <StableJabView world={world} />
      {/* Pub pint pickup */}
      <StablePintView world={world} />
      <PopText signal={skinnySignal} />

      {/* feathers */}
      {Array.from({ length: CONFIG.FEATHER_POOL }).map((_, i) => (
        <StableFeatherView key={i} world={world} index={i} color={activeMap.feather} />
      ))}

      {/* pigeon */}
      <StablePigeonView world={world} pigeon={pigeon} fatLevel={fatLevel} boost={pintBoost} strength={drunkStrength} deflateSignal={deflateN} active={!over && !confirmRestart} suppressQuips={scriptedLine.visible} />
      </BeerWorld>

      {/* Roadman-only speech follows the pigeon, upright and clear of screen edges. */}
      {pigeon.id === 'roadman' && (
        <StablePigeonSpeechBubble world={world} text={scriptedLine.text} visible={scriptedLine.visible} screenW={width} screenH={height} fatLevel={fatLevel} topInset={insets.top} bottomInset={insets.bottom} />
      )}

      {/* Web soft-focus overlay. Android's real beer blur is on BeerWorld above. */}
      <StableDrunkScreenFX
        level={Math.min(1.4, drunkLevel + (pintBoost ? 0.9 : 0))}
        boosted={pintBoost}
      />

      {/* "SKINNY AGAIN!" toast on jab pickup — above the blur so it stays crisp */}
      <SkinnyToast signal={skinnySignal} />

      {/* flap input layer (below HUD buttons). Single authoritative handler on the
          gesture-responder touch-DOWN event so a valid tap is captured immediately
          (not on release) and never depends on React render timing. */}
      <View
        testID="flap-area"
        style={StyleSheet.absoluteFill}
        onStartShouldSetResponder={() => true}
        onMoveShouldSetResponder={() => false}
        onResponderTerminationRequest={() => false}
        onResponderGrant={doFlap}
      />

      {/* HUD */}
      <SafeAreaView style={styles.hud} pointerEvents="box-none">
        <View style={styles.hudTop} pointerEvents="box-none">
          <View style={styles.leftCluster} pointerEvents="box-none">
            <Pressable testID="restart-button" onPress={openRestartConfirm} style={styles.restartBtn}>
              <Text style={styles.restartIcon}>↻</Text>
            </Pressable>
            <Pressable testID="exit-button" onPress={handleExit} style={styles.exit}>
              <Text style={styles.exitTxt}>‹ MENU</Text>
            </Pressable>
          </View>
          <DistanceHUD telemetry={telemetry} />
          <ChipHUD ref={chipHudRef} />
        </View>
        <View style={styles.fatMsgWrap} pointerEvents="none">
          <Text
            style={[styles.fatLabel, { opacity: extraLevel > 0 || fatLevel > 0 ? 1 : 0 }]}
            testID="fat-label"
          >
            {extraLevel > 0 ? EXTRA_FAT_LABELS[extraLevel - 1] : FAT_LABELS[fatLevel] || FAT_LABELS[0]}
          </Text>
        </View>
      </SafeAreaView>

      {shield && (
        <View style={styles.shield} pointerEvents="none" testID="shield-banner">
          <Text style={styles.shieldTxt}>SHIELD ACTIVE</Text>
        </View>
      )}

      <ReadyHint visible={!started && !over} preparing={!rendererReady} />

      {typeof __DEV__ !== 'undefined' && __DEV__ && devStats && (
        <View style={styles.devStats} pointerEvents="none" testID="dev-input-stats">
          <Text style={styles.devStatsTxt}>
            state:{devStats.state} raw:{devStats.raw} acc:{devStats.accepted} flap:{devStats.flaps} ign:{devStats.ignored}
            {devStats.lastReason ? ` (${devStats.lastReason})` : ''} match:{String(devStats.accepted === devStats.flaps)}
          </Text>
        </View>
      )}

      {typeof __DEV__ !== 'undefined' && __DEV__ && perfHud && (
        <View style={styles.perfHud} pointerEvents="none" testID="dev-perf-stats">
          <Text style={styles.devStatsTxt}>
            step:{perfHud.stepMs.toFixed(3)}ms chunk:{perfHud.chunkMs.toFixed(3)}ms maxChunk:{perfHud.maxChunkMs.toFixed(3)}ms pool:{CONFIG.OBSTACLE_POOL} recycles:{perfHud.recycles}{'\n'}
            mountsSinceStart building:{perfHud.mountsSinceStart ? perfHud.mountsSinceStart.building : '-'} structureShape:{perfHud.mountsSinceStart ? perfHud.mountsSinceStart.structureShape : '-'} obstacleView:{perfHud.mountsSinceStart ? perfHud.mountsSinceStart.obstacleView : '-'}{'\n'}
            adRotations:{perfHud.adRotations} adStorageWrites:{perfHud.adStorageWrites} gaps25ms+:{perfHud.frameGaps.map((g) => `${g.gapMs}ms@${g.distM}m`).join(',') || 'none'}
          </Text>
        </View>
      )}

      {confirmRestart && (
        <View style={styles.confirmOverlay} testID="restart-confirm-overlay" onStartShouldSetResponder={() => true}>
          <View style={styles.confirmCard}>
            <Text style={styles.confirmTitle}>RESTART RUN?</Text>
            <Text style={styles.confirmSub}>Start fresh with the same pigeon & map</Text>
            <Button testID="restart-confirm-yes" label="Restart" variant="primary" onPress={confirmRestartNow} style={styles.confirmBtn} />
            <Button testID="restart-cancel" label="Cancel" variant="ghost" onPress={cancelRestart} style={styles.confirmBtn} />
          </View>
        </View>
      )}

      {/* 1000m blackout Easter egg — covers everything, never blocks flaps */}
      <BlackoutOverlay telemetry={telemetry} />

      {over && (
        <GameOverOverlay
          message={over.message}
          chips={over.chips}
          distance={over.distance}
          bestDistance={Math.max(bestDistance, over.distance)}
          isNewBest={over.isNewBest}
          canRevive={canRevive}
          reviveBusy={reviveBusy}
          reviveMsg={reviveMsg}
          onPlayAgain={async () => {
            // occasional interstitial at the natural Game Over -> next-run
            // transition (never during gameplay; skipped for Remove Ads owners).
            await Ads.showInterstitialIfDue();
            setReviveMsg('');
            startRun();
          }}
          onRevive={doRevive}
          onMenu={handleExit}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000', overflow: 'hidden' },
  hud: { ...StyleSheet.absoluteFillObject, paddingHorizontal: 16 },
  hudTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 6 },
  leftCluster: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  restartBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.35)', alignItems: 'center', justifyContent: 'center' },
  restartIcon: { fontFamily: FONT, color: '#fff', fontSize: 24, fontWeight: '700', marginTop: -2 },
  distHud: { backgroundColor: 'rgba(0,0,0,0.3)', paddingVertical: 5, paddingHorizontal: 12, borderRadius: 16 },
  distTxt: { fontFamily: FONT, color: '#fff', fontWeight: '700', fontSize: 16, letterSpacing: 0.5 },
  exit: { backgroundColor: 'rgba(0,0,0,0.35)', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 20 },
  exitTxt: { fontFamily: FONT, color: '#fff', fontWeight: '700', fontSize: 14 },
  chipHud: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(0,0,0,0.35)', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 20 },
  chipIcon: { width: 18, height: 9, borderRadius: 3, backgroundColor: '#f4c542', borderWidth: 1.5, borderColor: '#c99a1e', transform: [{ rotate: '30deg' }] },
  chipTxt: { fontFamily: FONT, color: '#fff', fontWeight: '700', fontSize: 18 },
  fatMsgWrap: { alignItems: 'center', marginTop: 10 },
  fatLabel: { fontFamily: FONT, color: COLORS.yellow, fontSize: 16, fontWeight: '700', textShadowColor: 'rgba(0,0,0,0.4)', textShadowRadius: 3 },
  shield: { position: 'absolute', bottom: 60, alignSelf: 'center', backgroundColor: 'rgba(62,242,192,0.9)', paddingVertical: 8, paddingHorizontal: 20, borderRadius: 20, alignItems: 'center' },
  shieldTxt: { fontFamily: FONT, color: '#053a2e', fontWeight: '700', fontSize: 16, letterSpacing: 1 },
  hint: { position: 'absolute', top: '46%', left: 0, right: 0, alignItems: 'center' },
  hintTxt: { fontFamily: FONT, color: '#fff', fontSize: 34, fontWeight: '700', letterSpacing: 2, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 6 },
  hintSub: { fontFamily: FONT, color: '#fff', fontSize: 15, marginTop: 4, opacity: 0.9 },
  devStats: { position: 'absolute', bottom: 4, left: 4, right: 4, backgroundColor: 'rgba(0,0,0,0.55)', paddingVertical: 3, paddingHorizontal: 6, borderRadius: 6, zIndex: 60 },
  perfHud: { position: 'absolute', bottom: 24, left: 4, right: 4, backgroundColor: 'rgba(0,0,0,0.55)', paddingVertical: 3, paddingHorizontal: 6, borderRadius: 6, zIndex: 60 },
  devStatsTxt: { fontFamily: FONT, color: '#7CFFB2', fontSize: 10, fontWeight: '700' },
  confirmOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(15,8,30,0.78)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  confirmCard: { width: '100%', maxWidth: 340, backgroundColor: COLORS.card, borderRadius: 24, padding: 24, alignItems: 'center' },
  confirmTitle: { fontFamily: FONT, color: COLORS.yellow, fontSize: 28, fontWeight: '700', letterSpacing: 1 },
  confirmSub: { fontFamily: FONT, color: COLORS.textDim, fontSize: 14, marginTop: 6, textAlign: 'center' },
  confirmBtn: { width: '100%', marginTop: 12 },
  blackout: { ...StyleSheet.absoluteFillObject, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40, zIndex: 50 },
  blackoutTxt: { fontFamily: FONT, color: '#fff', fontSize: 22, fontWeight: '700', textAlign: 'center', lineHeight: 30, letterSpacing: 0.5 },
  pop: { position: 'absolute', top: '25%', left: 0, right: 0, alignItems: 'center', zIndex: 40 },
  popTxt: { fontFamily: FONT, color: '#fff', fontSize: 34, fontWeight: '700', letterSpacing: 1, textShadowColor: '#ff3b8d', textShadowRadius: 8, textShadowOffset: { width: 0, height: 2 } },
  calloutShown: { opacity: 1 },
  calloutHidden: { opacity: 0 },
});
